<?php $this->beginContent('/layouts/main'); ?>
<div class="container">
	<div id="content1a" style="padding:10px 10px 10px 10px;">
		<?php echo $content; ?>
	</div><!-- content -->
</div>
<?php $this->endContent(); ?>